const MAX_TABS = 50;
const OPENED_TAB_IDS_KEY = "openedTabIds";

chrome.action.onClicked.addListener(async (tab) => {
  await openUrlsFromClipboard(tab);
});

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command === "copy-selection-and-open") {
    await copySelectionAndOpen(tab);
    return;
  }

  if (command === "close-opened-tabs") {
    await closeOpenedTabs();
  }
});

async function openUrlsFromClipboard(tab) {
  await setBadge("...", "#5f6368");
  try {
    const urls = await readClipboardUrlsFromActiveTab(tab);
    await openUrls(urls);
  } catch (error) {
    console.error(error);
    await setBadge("!", "#b3261e");
    clearBadgeSoon();
  }
}

async function copySelectionAndOpen(tab) {
  await setBadge("...", "#5f6368");

  try {
    const copied = await copySelectionInActiveTab(tab);
    const urls = copied.length > 0 ? copied : await readClipboardUrlsFromActiveTab(tab);

    await openUrls(urls);
  } catch (error) {
    console.error(error);
    await setBadge("!", "#b3261e");
    clearBadgeSoon();
  }
}

async function openUrls(urls) {
  if (urls.length === 0) {
    await setBadge("0", "#b3261e");
    clearBadgeSoon();
    return;
  }

  const urlsToOpen = urls.slice(0, MAX_TABS);
  const tabs = await Promise.all(urlsToOpen.map((url) => chrome.tabs.create({ url, active: false })));

  await rememberOpenedTabs(tabs.map((tab) => tab.id).filter(Boolean));
  await setBadge(String(urlsToOpen.length), "#137333");
  clearBadgeSoon();
}

async function readClipboardUrlsFromActiveTab(tab) {
  if (!tab?.id || !isScriptableUrl(tab.url)) {
    throw new Error("Open a normal web page before clicking the extension.");
  }

  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: readClipboardUrlsInPage
  });

  return result?.result ?? [];
}

async function copySelectionInActiveTab(tab) {
  if (!tab?.id || !isScriptableUrl(tab.url)) {
    throw new Error("Open a normal web page before using this command.");
  }

  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: copySelectionUrlsInPage
  });

  return result?.result ?? [];
}

function isScriptableUrl(url = "") {
  return url.startsWith("http://") || url.startsWith("https://") || url.startsWith("file://");
}

async function setBadge(text, color) {
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color });
}

function clearBadgeSoon() {
  setTimeout(() => {
    chrome.action.setBadgeText({ text: "" });
  }, 2200);
}

async function rememberOpenedTabs(tabIds) {
  await chrome.storage.local.set({ [OPENED_TAB_IDS_KEY]: tabIds });
}

async function closeOpenedTabs() {
  const stored = await chrome.storage.local.get(OPENED_TAB_IDS_KEY);
  const tabIds = stored[OPENED_TAB_IDS_KEY] ?? [];

  if (tabIds.length === 0) {
    await setBadge("0", "#5f6368");
    clearBadgeSoon();
    return;
  }

  const existingTabIds = [];

  for (const tabId of tabIds) {
    try {
      await chrome.tabs.get(tabId);
      existingTabIds.push(tabId);
    } catch {
      // Already closed.
    }
  }

  if (existingTabIds.length > 0) {
    await chrome.tabs.remove(existingTabIds);
  }

  await chrome.storage.local.set({ [OPENED_TAB_IDS_KEY]: [] });
  await setBadge(String(existingTabIds.length), "#5f6368");
  clearBadgeSoon();
}

async function copySelectionUrlsInPage() {
  const selection = window.getSelection();

  if (!selection || selection.rangeCount === 0 || selection.toString().trim() === "") {
    return [];
  }

  const container = document.createElement("div");

  for (let index = 0; index < selection.rangeCount; index += 1) {
    container.append(selection.getRangeAt(index).cloneContents());
  }

  const text = container.textContent ?? selection.toString();
  const html = container.innerHTML;

  await navigator.clipboard.write([
    new ClipboardItem({
      "text/plain": new Blob([text], { type: "text/plain" }),
      "text/html": new Blob([html], { type: "text/html" })
    })
  ]);

  return extractUrls({ html, text });

  function extractUrls({ html, text }) {
    const textUrls = extractTextUrls(text);

    if (textUrls.length > 0) {
      return dedupe(textUrls);
    }

    return dedupe([...extractHrefUrls(html), ...extractTextUrls(stripHtml(html))]);
  }

  function extractHrefUrls(html) {
    if (!html) return [];

    const document = new DOMParser().parseFromString(html, "text/html");

    return Array.from(document.querySelectorAll("a[href]"))
      .map((anchor) => anchor.getAttribute("href"))
      .map(normalizeUrl)
      .filter(Boolean);
  }

  function extractTextUrls(text) {
    if (!text) return [];

    return text
      .split(/[\s,\t\r\n]+/)
      .map(cleanCellValue)
      .flatMap(splitPossibleUrls)
      .map(normalizeUrl)
      .filter(Boolean);
  }

  function stripHtml(html) {
    if (!html) return "";
    return new DOMParser().parseFromString(html, "text/html").body.textContent ?? "";
  }

  function splitPossibleUrls(value) {
    const matches = value.match(/https?:\/\/[^\s"'<>]+|www\.[^\s"'<>]+/gi);
    return matches ?? [value];
  }

  function cleanCellValue(value) {
    return value.trim().replace(/^["']|["']$/g, "").replace(/[),.;:]+$/g, "");
  }

  function normalizeUrl(value) {
    if (!value) return "";

    const withProtocol = value.startsWith("www.") ? `https://${value}` : value;

    try {
      const url = new URL(withProtocol);
      if (url.protocol !== "http:" && url.protocol !== "https:") return "";

      return unwrapRedirect(url).href;
    } catch {
      return "";
    }
  }

  function unwrapRedirect(url) {
    if (url.hostname === "www.google.com" && url.pathname === "/url" && url.searchParams.has("q")) {
      try {
        return new URL(url.searchParams.get("q"));
      } catch {
        return url;
      }
    }

    return url;
  }

  function dedupe(urls) {
    const seen = new Set();

    return urls.filter((url) => {
      if (seen.has(url)) return false;
      seen.add(url);
      return true;
    });
  }
}

async function readClipboardUrlsInPage() {
  const clipboard = await readClipboard();
  return extractUrls(clipboard);

  async function readClipboard() {
    const result = { html: "", text: "" };

    if (navigator.clipboard.read) {
      const items = await navigator.clipboard.read();

      for (const item of items) {
        if (item.types.includes("text/html")) {
          result.html += await readClipboardItemAsText(item, "text/html");
        }

        if (item.types.includes("text/plain")) {
          result.text += await readClipboardItemAsText(item, "text/plain");
        }
      }

      return result;
    }

    result.text = await navigator.clipboard.readText();
    return result;
  }

  async function readClipboardItemAsText(item, type) {
    const blob = await item.getType(type);
    return blob.text();
  }

  function extractUrls({ html, text }) {
    const textUrls = extractTextUrls(text);

    if (textUrls.length > 0) {
      return dedupe(textUrls);
    }

    return dedupe([...extractHrefUrls(html), ...extractTextUrls(stripHtml(html))]);
  }

  function extractHrefUrls(html) {
    if (!html) return [];

    const document = new DOMParser().parseFromString(html, "text/html");

    return Array.from(document.querySelectorAll("a[href]"))
      .map((anchor) => anchor.getAttribute("href"))
      .map(normalizeUrl)
      .filter(Boolean);
  }

  function extractTextUrls(text) {
    if (!text) return [];

    return text
      .split(/[\s,\t\r\n]+/)
      .map(cleanCellValue)
      .flatMap(splitPossibleUrls)
      .map(normalizeUrl)
      .filter(Boolean);
  }

  function stripHtml(html) {
    if (!html) return "";
    return new DOMParser().parseFromString(html, "text/html").body.textContent ?? "";
  }

  function splitPossibleUrls(value) {
    const matches = value.match(/https?:\/\/[^\s"'<>]+|www\.[^\s"'<>]+/gi);
    return matches ?? [value];
  }

  function cleanCellValue(value) {
    return value.trim().replace(/^["']|["']$/g, "").replace(/[),.;:]+$/g, "");
  }

  function normalizeUrl(value) {
    if (!value) return "";

    const withProtocol = value.startsWith("www.") ? `https://${value}` : value;

    try {
      const url = new URL(withProtocol);
      if (url.protocol !== "http:" && url.protocol !== "https:") return "";

      return unwrapRedirect(url).href;
    } catch {
      return "";
    }
  }

  function unwrapRedirect(url) {
    if (url.hostname === "www.google.com" && url.pathname === "/url" && url.searchParams.has("q")) {
      try {
        return new URL(url.searchParams.get("q"));
      } catch {
        return url;
      }
    }

    return url;
  }

  function dedupe(urls) {
    const seen = new Set();

    return urls.filter((url) => {
      if (seen.has(url)) return false;
      seen.add(url);
      return true;
    });
  }
}
