# Pastey URL Opener

スプレッドシートでコピーした複数セルのURLを、それぞれ新しいタブで開くChrome/Edge拡張機能です。

セルの表示文字列にハイパーリンクが挿入されている場合も、コピー内容にHTMLリンク情報が含まれていればリンク先URLを開きます。

## 使い方

1. Google SheetsやExcel Onlineなどで、URLが入ったセル範囲を選択します。
2. コピーします。
3. コピー元のタブを開いたまま、ブラウザの拡張機能アイコンをクリックします。

キーボードだけで使う場合は、コピー後に `Command + Shift + Y` を押します。

選択範囲のコピーからURLを開くまで一括で行う場合は、セル範囲を選択して `Command + Shift + U` を押します。
前回この拡張機能で開いたタブをまとめて閉じる場合は、`Command + Shift + L` を押します。

ショートカットは Chrome の `chrome://extensions/shortcuts` で変更できます。
Chrome側で別のショートカットと衝突した場合は、この画面で「Copy current selection and open URLs」に割り当て直してください。

## インストール

1. Chromeで `chrome://extensions/` を開きます。
2. 右上の「デベロッパー モード」をオンにします。
3. 「パッケージ化されていない拡張機能を読み込む」をクリックします。
4. このフォルダを選択します。

Edgeの場合は `edge://extensions/` で同じ手順です。

## 動作メモ

- `http://` と `https://` のURLを開きます。
- `www.example.com` のような値は `https://www.example.com` として開きます。
- Google SheetsなどからコピーされたHTML内の `<a href="...">` を読み取ります。
- URL文字列がコピーされている場合は、HTML内の隠れたリンクよりURL文字列を優先します。
- 重複URLは1回だけ開きます。
- 誤操作を避けるため、1回で開くタブ数は最大50件です。
- 開いた件数は拡張機能アイコン上の小さなバッジに一時表示されます。
- 前回この拡張機能で開いたタブは、ショートカットで一括クローズできます。
- `chrome://extensions/` などのブラウザ内部ページ上では動作しません。Google Sheetsなど通常のWebページを開いた状態でクリックしてください。
